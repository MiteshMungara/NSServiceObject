//
//  MenuView.h
//  MyGlams
//
//  Created by isquare2 on 1/13/16.
//  Copyright © 2016 MitSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "ProjectHeader.h"
@interface MenuView : UIViewController
{
    AppDelegate *app;
    CGRect screenBounds;
}

@property (nonatomic,weak) IBOutlet UIImageView *image1,*image2,*image3,*image4;
-(IBAction)menuBtnClicked:(id)sender;
@end
