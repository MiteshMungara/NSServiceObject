//
//  MenuView.m
//  MyGlams
//
//  Created by isquare2 on 1/13/16.
//  Copyright © 2016 MitSoft. All rights reserved.
//

#import "MenuView.h"
#import "LaterVC.h"
//#import "UploadView.h"
#import "ProfileVC.h"
#import "FavoriteVC.h"
#import "RemindMeVC.h"

@interface MenuView ()

@end

@implementation MenuView

- (void)viewDidLoad {
    [super viewDidLoad];
    app = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    screenBounds = [[UIScreen mainScreen] bounds];
}

# pragma mark - MenuBtnClicked
-(IBAction)menuBtnClicked:(id)sender
{
    UINavigationController *navigationController = (UINavigationController *)app.window.rootViewController;
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    
    UIButton *btn = (UIButton *)sender;
    if (btn.tag==1)
    {
        NSString *useridstr = [[NSUserDefaults standardUserDefaults] stringForKey:@"User_id"];
        
        if (useridstr) {
        self.image1.image=[UIImage imageNamed:@"Selected_btn_orange.png"];
        ProfileVC *photoCV = (ProfileVC *)[mainStoryboard instantiateViewControllerWithIdentifier: @"ProfileVC"];
        [navigationController pushViewController:photoCV animated:NO];
        }
        else
        {
            ALERT_VIEW(@"You are not registered.", @"Would you like to register info the application")
        }
    }
    else if (btn.tag==2)
    {
        NSString *useridstr = [[NSUserDefaults standardUserDefaults] stringForKey:@"User_id"];
        
        if (useridstr) {
        self.image2.image=[UIImage imageNamed:@"Selected_btn_orange.png"];
        FavoriteVC *photoCV = (FavoriteVC *)[mainStoryboard instantiateViewControllerWithIdentifier: @"FavoriteVC"];
        [navigationController pushViewController:photoCV animated:NO];
        }
        else
        {
            ALERT_VIEW(@"You are not registered.", @"Would you like to register info the application")
        }
    }
    else if (btn.tag==3)
    {
        NSString *useridstr = [[NSUserDefaults standardUserDefaults] stringForKey:@"User_id"];
        
        if (useridstr) {
        self.image3.image=[UIImage imageNamed:@"Selected_btn_orange.png"];
        RemindMeVC *profileView = (RemindMeVC *)[mainStoryboard instantiateViewControllerWithIdentifier: @"RemindMeVC"];
        [navigationController pushViewController:profileView animated:NO];
        }
        else
        {
            ALERT_VIEW(@"You are not registered.", @"Would you like to register info the application")
        }
    }
    else if (btn.tag==4)
    {

        self.image4.image=[UIImage imageNamed:@"Selected_btn_orange.png"];
        LaterVC *profileView = (LaterVC *)[mainStoryboard instantiateViewControllerWithIdentifier: @"LaterVC"];
        [navigationController pushViewController:profileView animated:NO];
    }
}



#pragma  mark - Stop
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
